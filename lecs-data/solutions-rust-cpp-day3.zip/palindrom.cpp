#include <bits/stdc++.h>

#define rep(a, b)   for(int a = 0; a < (b); ++a)
#define all(a)      begin(a),end(a)
#define endl        '\n'

using namespace std;
using Graph = vector<vector<int>>;
using ll = long long;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.precision(10);

    string s; cin>>s;
    int n = size(s);
    vector dp(n+1, vector(n+1,n)); // dp[i][j] = answer for substring s[i..j]
    rep(i,n) dp[i][i] = 0; // size 0
    rep(i,n) dp[i][i+1] = 0; // size 1

    for(int w=2; w<=n; ++w) {
        rep(l,n-w+1) { // l in [0,n-w]
            int r = l+w;
            dp[l][r] = min(dp[l][r], 1+dp[l+1][r]); // delete left
            dp[l][r] = min(dp[l][r], 1+dp[l][r-1]); // delete right
            dp[l][r] = min(dp[l][r], 1+dp[l+1][r-1]); // make sides equal
            if(s[l]==s[r-1]) dp[l][r] = min(dp[l][r], dp[l+1][r-1]); // sides are already equal
        }
    }

    cout << dp[0][n] << endl;

    return 0;
}
