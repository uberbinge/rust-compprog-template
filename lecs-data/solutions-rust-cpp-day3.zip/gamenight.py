w, h = map(int,input().split())
is_winning = [[True for _ in range(w)] for _ in range(h)]

for i in range(h):
    for j in range(w):
        if i==0 and j==0:
            continue
        reaches_losing = False
        if j>0:
            reaches_losing |= not is_winning[i][j-1]
        if j>1:
            reaches_losing |= not is_winning[i][j-2]
        if i>0:
            reaches_losing |= not is_winning[i-1][j]
        if i>1:
            reaches_losing |= not is_winning[i-2][j]
        is_winning[i][j] = reaches_losing

print(1 if is_winning[-1][-1] else 2)
                