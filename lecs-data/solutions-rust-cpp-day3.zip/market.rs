use std::{
    fmt::Debug,
    io::{self, BufWriter, Lines, StdinLock, StdoutLock, Write},
    str::FromStr,
};

fn main() {
    let mut io = Io::new();

    let t: usize = io.read();
    for _ in 0..t {
        let n: usize = io.read();
        let a: Vec<u32> = io.collect(n);

        let mut ending_at = vec![1; n];
        for i in 1..n {
            if a[i] > a[i - 1] {
                ending_at[i] = ending_at[i - 1] + 1;
            }
        }

        let mut starting_at = vec![1; n];
        for i in (0..n - 1).rev() {
            if a[i] < a[i + 1] {
                starting_at[i] = starting_at[i + 1] + 1;
            }
        }

        let mut ans = 0;
        for i in 0..n {
            ans = ans.max(starting_at[i]).max(ending_at[i]);
            if i > 0 {
                ans = ans.max(starting_at[i] + 1);
            }
            if i + 1 < n {
                ans = ans.max(ending_at[i] + 1);
            }
            if i + 2 < n && a[i] + 1 < a[i + 2] {
                ans = ans.max(ending_at[i] + 1 + starting_at[i + 2]);
            }
        }

        putln!(io, "{ans}");
    }
}

struct Io {
    line: String,
    offset: usize,
    lines: Lines<StdinLock<'static>>,
    writer: BufWriter<StdoutLock<'static>>,
}

impl Io {
    fn new() -> Self {
        Self {
            line: String::new(),
            offset: 0,
            lines: io::stdin().lines(),
            writer: BufWriter::new(io::stdout().lock()),
        }
    }

    fn next_token(&mut self) -> &str {
        loop {
            if let Some(trim_len) = self.line[self.offset..].find(|c: char| !c.is_whitespace()) {
                let trimmed = &self.line[self.offset + trim_len..];
                let len = trimmed.find(char::is_whitespace).unwrap_or(trimmed.len());
                self.offset += trim_len + len;
                break &trimmed[..len];
            }

            self.line = self
                .lines
                .next()
                .expect("unexpected end-of-file")
                .expect("failed to read input");
            self.offset = 0;
        }
    }

    fn read<T: FromStr>(&mut self) -> T
    where
        T::Err: Debug,
    {
        self.next_token().parse().expect("failed to parse input")
    }

    fn collect<T: FromStr, C: FromIterator<T>>(&mut self, len: usize) -> C
    where
        T::Err: Debug,
    {
        (0..len).map(|_| self.read()).collect()
    }
}

#[macro_export]
macro_rules! putln {
    ($io:expr, $($args:tt)*) => {
        writeln!($io.writer, $($args)*).expect("failed to write output")
    };
}

#[macro_export]
macro_rules! put {
    ($io:expr, $($args:tt)*) => {
        write!($io.writer, $($args)*).expect("failed to write output")
    };
}
