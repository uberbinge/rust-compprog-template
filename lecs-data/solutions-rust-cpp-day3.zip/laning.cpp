
#include <bits/stdc++.h>

#define rep(a, b)   for(int a = 0; a < (b); ++a)
#define all(a)      (a).begin(),(a).end()
#define endl        '\n'

using namespace std;
using Graph = vector<vector<int>>;
using ll = long long;

int dfs(Graph& g, vector<bool>& visited, int v, int& mx) {
    visited[v] = true;
    int sub1 = 0, sub2 = 0;
    for(auto nei : g[v]) {
        if(visited[nei]) continue;
        auto sz = dfs(g, visited, nei, mx);
        if(sz>sub2) swap(sz,sub2);
        if(sub2>sub1) swap(sub1,sub2);
    }
    mx = max(mx, sub1+sub2);
    return sub1 + 1;
}


int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.precision(10);


    int n,m; cin>>n>>m;
    Graph g(n);
    rep(i,m) {
        int a,b; cin>>a>>b; --a; --b;
        g[a].push_back(b);
        g[b].push_back(a);
    }

    vector<int> trees;
    vector<bool> visited(n, false);
    rep(i,n) {
        if(visited[i]) continue;
        int tree = 0;
        dfs(g, visited, i, tree);
        trees.push_back(tree);
    }

    sort(all(trees), greater<>());

    auto iceil2 = [](int i){ return (i+1)/2; };
    int res = trees.front();
    if(size(trees)>1)
        res = max(res, iceil2(trees[0]) + iceil2(trees[1]) + 1);
    if(size(trees)>2)
        res = max(res, iceil2(trees[1]) + iceil2(trees[2]) + 2);
    cout << res << endl;

    return 0;
}

