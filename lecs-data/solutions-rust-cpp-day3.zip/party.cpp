#include <bits/stdc++.h>

#define rep(a, b)   for(int a = 0; a < (b); ++a)

using namespace std;

int main() {
    ios::sync_with_stdio(false);

    int n; cin>>n;
    vector wi(n,0ll); // picked
    vector wo(n,0ll); // not picked
    vector p(n,-1);
    rep(i,n) cin >> wi[i];
    rep(i,n-1) cin>>p[i+1], p[i+1]--;

    // tree is given in nice order :)
    for(int v=n-1; v>0; --v) {
        wi[p[v]] += wo[v];
        wo[p[v]] += max(wi[v], wo[v]);
    }

    cout << max(wi[0],wo[0]) << endl;

    return 0;
}

