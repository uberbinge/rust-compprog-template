#include <bits/stdc++.h>

#define rep(a, b)   for(int a = 0; a < (b); ++a)
#define all(a)      (a).begin(),(a).end()
#define endl        '\n'

using namespace std;
using ll = long long;
using Graph = vector<vector<pair<int,int>>>;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int t; cin >> t;
    while (t--) {
        int n; cin>>n;
        vector arr(n,0);
        rep(i,n) cin>>arr[i];

        vector end(n,1); // longest streak ending at i
        vector beg(n,1); // longest streak beginning at i
        rep(i,n-1) {
            int j = n-i-1;
            if(arr[i+1]>arr[i]) end[i+1] = 1+end[i];
            if(arr[j-1]<arr[j]) beg[j-1] = 1+beg[j];
        }

        // longest streak (+1 if not already complete)
        int res = *max_element(all(end));
        if(res<n) res++;
        
        // merge two streaks
        rep(i,n-2) if(arr[i+2]-arr[i]>1) res = max(res,end[i]+1+beg[i+2]);
        cout << res << endl;
    }
    return 0;
}
