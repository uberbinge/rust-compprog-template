use std::{
    fmt::Debug,
    io::{self, BufWriter, Lines, StdinLock, StdoutLock, Write},
    str::FromStr,
};

fn main() {
    let mut io = Io::new();

    let w: usize = io.read();
    let h: usize = io.read();
    let mut winning = vec![vec![false; h]; w];
    for x in (0..w).rev() {
        for y in (0..h).rev() {
            winning[x][y] = [(1, 0), (2, 0), (0, 1), (0, 2)]
                .into_iter()
                .filter_map(|(dx, dy)| {
                    // Check if the moves gets us into a loosing state (for the other player)
                    winning.get(x + dx)?.get(y + dy).map(|w| !w)
                })
                .reduce(|a, b| a || b)
                .unwrap_or(true);
        }
    }

    let ans = if winning[0][0] { 1 } else { 2 };
    putln!(io, "{ans}");
}

struct Io {
    line: String,
    offset: usize,
    lines: Lines<StdinLock<'static>>,
    writer: BufWriter<StdoutLock<'static>>,
}

impl Io {
    fn new() -> Self {
        Self {
            line: String::new(),
            offset: 0,
            lines: io::stdin().lines(),
            writer: BufWriter::new(io::stdout().lock()),
        }
    }

    fn next_token(&mut self) -> &str {
        loop {
            if let Some(trim_len) = self.line[self.offset..].find(|c: char| !c.is_whitespace()) {
                let trimmed = &self.line[self.offset + trim_len..];
                let len = trimmed.find(char::is_whitespace).unwrap_or(trimmed.len());
                self.offset += trim_len + len;
                break &trimmed[..len];
            }

            self.line = self
                .lines
                .next()
                .expect("unexpected end-of-file")
                .expect("failed to read input");
            self.offset = 0;
        }
    }

    fn read<T: FromStr>(&mut self) -> T
    where
        T::Err: Debug,
    {
        self.next_token().parse().expect("failed to parse input")
    }

    fn collect<T: FromStr, C: FromIterator<T>>(&mut self, len: usize) -> C
    where
        T::Err: Debug,
    {
        (0..len).map(|_| self.read()).collect()
    }
}

#[macro_export]
macro_rules! putln {
    ($io:expr, $($args:tt)*) => {
        writeln!($io.writer, $($args)*).expect("failed to write output")
    };
}

#[macro_export]
macro_rules! put {
    ($io:expr, $($args:tt)*) => {
        write!($io.writer, $($args)*).expect("failed to write output")
    };
}
