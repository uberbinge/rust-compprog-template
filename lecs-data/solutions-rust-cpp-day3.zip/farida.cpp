
#include <bits/stdc++.h>

#define rep(a, b)   for(int a = 0; a < (b); ++a)
#define all(a)      (a).begin(),(a).end()
#define endl        '\n'

using namespace std;
using Graph = vector<vector<int>>;
using ll = long long;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.precision(10);

    int n; cin>>n;
    ll prev=0, prev2=0;
    while(n--) {
        int a; cin>>a;
        tie(prev, prev2) = pair(a+prev2, max(prev,prev2));
    }

    cout << max(prev, prev2) << endl;

    return 0;
}

