#include <bits/stdc++.h> // includes all; gcc only

#define rep(a, b)   for(int a = 0; a < (b); ++a)
#define all(a)      begin(a),end(a)
#define endl        '\n'

using namespace std;
using Graph = vector<vector<int>>;
using ll = long long;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.precision(10);

    int t; cin>>t;
    while(t--) {
        int n,k; cin>>n>>k;
        vector tour(n,0);
        rep(i,n) cin>>tour[i];
        map<int,int> fst, lst;
        rep(i,n) lst[tour[i]] = i;
        rep(i,n) fst[tour[n-i-1]] = n-i-1;
        rep(i,k) {
            int a,b; cin>>a>>b;
            bool works = fst.count(a)+fst.count(b) == 2 && fst[a]<=lst[b];
            cout << (works ? "sameday" : "dhlspeed") << endl;
        }
    }

    return 0;
}
