#include <bits/stdc++.h>

#define rep(a, b)   for(int a = 0; a < (b); ++a)
#define all(a)      begin(a),end(a)
#define endl        '\n'

using namespace std;
using Graph = vector<vector<int>>;
using ll = long long;

struct SegTree {
    int n;
    vector<int> d;
    ll query(int l, int r) { return query(1,0,n,l,r); }
    ll query(int v, int l, int r, int ql, int qr) {
        if(ql<=l && r<=qr) return d[v];
        if(qr<=l || r<=ql) return 0;
        int m = (r+l)/2;
        return query(2*v, l, m, ql, qr) + query(2*v+1, m, r, ql, qr);
    }
    ll update(int i, ll x) { return update(1,0,n,i,x); }
    ll update(int v, int l, int r, int i, ll x) {
        if(i<l||i>=r) return d[v];
        if(r-l==1) return d[v] = x;
        int m = (r+l)/2;
        return d[v] = update(2*v, l, m, i, x) + update(2*v+1, m, r, i, x);
    }
};

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.precision(10);

    // input
    int n; cin>>n;
    vector perm(n,0);
    rep(i,n) cin>>perm[i];

    // prepare segtree
    SegTree seg;
    seg.n = n;
    seg.d = vector(4*n,0);

    ll res = 0;
    rep(i,n) { // insert elements from left to right into segtree
        ll left = i; // num elements left of i
        ll smaller = perm[i]; // num elements smaller than p[i]
        auto bigger_left = seg.query(perm[i],n);
        auto smaller_left = left - bigger_left;
        auto smaller_right = smaller - smaller_left;
        res += bigger_left * smaller_right;
        seg.update(perm[i],1);
    }

    cout << res << endl;

    return 0;
}
