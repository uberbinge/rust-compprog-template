#include <bits/stdc++.h>

#define rep(a, b)   for(int a = 0; a < (b); ++a)
#define all(a)      begin(a),end(a)
#define endl        '\n'

using namespace std;
using Graph = vector<vector<int>>;
using ll = long long;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.precision(10);

    // input
    int n,f,q; cin>>n>>f>>q;
    vector req(f,0ll);
    rep(i,f) cin>>req[i];

    // apply water
    vector water(n,0ll); // initial diff array
    rep(i,q) {
        ll l,r,x; cin>>l>>r>>x; l--; // make 0-based right exclusive
        water[l]+=x;
        if(r<n) water[r]-=x;
    }
    inclusive_scan(all(water), begin(water)); // prefix sum

    // assign flowers
    vector sol(n,0);
    ll needed = 0;
    set<pair<ll,int>,greater<>> beds;
    rep(i,n) beds.emplace(water[i], i);
    rep(i,f) {
        auto it = beds.lower_bound(pair(req[i],n)); // bed with most water that is still <= limit of current flower
        if(it==end(beds)) cout << -1, exit(0);
        auto d = *it;
        auto [water, idx] = *it;
        beds.erase(it);
        needed += req[i] - water;
        sol[idx] = i+1;
    }

    // output
    cout << needed << endl;
    rep(i,n) cout << sol[i] << ' ';
    cout << endl;

    return 0;
}
