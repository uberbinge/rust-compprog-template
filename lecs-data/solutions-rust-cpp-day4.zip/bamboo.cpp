
#include <bits/stdc++.h>

#define rep(a, b)   for(int a = 0; a < (b); ++a)
#define all(a)      begin(a),end(a)
#define endl        '\n'

using namespace std;
using Graph = vector<vector<int>>;
using ll = long long;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.precision(10);

    // input
    int n,m,q; cin>>n>>m>>q;
    vector arr(n,0ll);
    rep(i,n) cin>>arr[i];

    // updates
    vector diff = arr;
    rep(i,n-1) diff[i+1] = arr[i+1]-arr[i];
    rep(i,m) {
        ll l,r,x; cin>>l>>r>>x; l--; // make 0-based right exclusive
        diff[l]+=x;
        if(r<n) diff[r]-=x;
    }

    // queries
    vector pref = diff;
    inclusive_scan(all(pref), begin(pref));
    inclusive_scan(all(pref), begin(pref));
    rep(i,q) {
        int l,r; cin>>l>>r; l--; // make 0-based right exclusive
        cout << pref[r-1] - (l ? pref[l-1] : 0) << endl;;
    }

    return 0;
}
