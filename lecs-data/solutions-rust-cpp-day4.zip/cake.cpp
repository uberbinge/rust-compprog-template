#include <bits/stdc++.h>

#define rep(a, b)   for(int a = 0; a < (b); ++a)
#define all(a)      begin(a),end(a)
#define endl        '\n'

using namespace std;
using Graph = vector<vector<int>>;
using ll = long long;

struct SegTree {
    int n;
    vector<ll> d;
    ll query(int l, int r) { return query(1,0,n,l,r); }
    ll query(int v, int l, int r, int ql, int qr) {
        if(ql<=l && r<=qr) return d[v];
        if(qr<=l || r<=ql) return 0;
        int m = (r+l)/2;
        return gcd(
                query(2*v  , l, m, ql, qr),
                query(2*v+1, m, r, ql, qr));
    }
    ll update(int i, ll x) { return update(1,0,n,i,x); }
    ll update(int v, int l, int r, int i, ll x) {
        if(i<l||i>=r) return d[v];
        if(r-l==1) return d[v] = x;
        int m = (r+l)/2;
        return d[v] = gcd(
                update(2*v  , l, m, i, x),
                update(2*v+1, m, r, i, x));
    }
};

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.precision(10);

    // input
    int n,q; cin>>n>>q;
    vector arr(n,0ll);
    rep(i,n) cin>>arr[i];

    // prepare segtree
    SegTree seg;
    seg.n = n;
    seg.d = vector(4*n,0ll);
    rep(i,n) seg.update(i,arr[i]);

    // answer questions
    rep(qi,q) {
        char t; cin>>t;
        if(t=='!') {
            string name; cin>>name;
            int i; cin>>i; --i;
            ll sub; cin>>sub;
            arr[i] -= sub;
            seg.update(i,arr[i]);
        } else {
            int l,r; cin>>l>>r; --l; // make 0-based right exclusive
            cout << seg.query(l,r) << endl;
        }
    }

    return 0;
}
