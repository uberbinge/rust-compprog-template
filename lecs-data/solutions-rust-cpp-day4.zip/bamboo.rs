use std::{
    fmt::Debug,
    io::{self, BufWriter, Lines, StdinLock, StdoutLock, Write},
    str::FromStr,
};

fn main() {
    let mut io = Io::new();

    let n: usize = io.read();
    let m: usize = io.read();
    let q: usize = io.read();
    let mut h: Vec<i64> = io.collect(n);
    for i in (1..n).rev() {
        h[i] -= h[i - 1];
    }

    for _ in 0..m {
        let l = io.read::<usize>() - 1;
        let r: usize = io.read();
        let d: i64 = io.read();
        h[l] += d;
        if let Some(entry) = h.get_mut(r) {
            *entry -= d;
        }
    }

    for _ in 0..2 {
        for i in 1..n {
            h[i] += h[i - 1];
        }
    }

    for _ in 0..q {
        let l = io.read::<usize>() - 1;
        let r: usize = io.read();
        let ans = h[r - 1] - l.checked_sub(1).map_or(0, |l_minus_one| h[l_minus_one]);
        putln!(io, "{ans}");
    }
}

struct Io {
    line: String,
    offset: usize,
    lines: Lines<StdinLock<'static>>,
    writer: BufWriter<StdoutLock<'static>>,
}

#[allow(dead_code)]
impl Io {
    fn new() -> Self {
        Self {
            line: String::new(),
            offset: 0,
            lines: io::stdin().lines(),
            writer: BufWriter::new(io::stdout().lock()),
        }
    }

    fn next_token(&mut self) -> &str {
        loop {
            if let Some(trim_len) = self.line[self.offset..].find(|c: char| !c.is_whitespace()) {
                let trimmed = &self.line[self.offset + trim_len..];
                let len = trimmed.find(char::is_whitespace).unwrap_or(trimmed.len());
                self.offset += trim_len + len;
                break &trimmed[..len];
            }

            self.line = self
                .lines
                .next()
                .expect("unexpected end-of-file")
                .expect("failed to read input");
            self.offset = 0;
        }
    }

    fn read<T: FromStr>(&mut self) -> T
    where
        T::Err: Debug,
    {
        self.next_token().parse().expect("failed to parse input")
    }

    fn collect<T: FromStr, C: FromIterator<T>>(&mut self, len: usize) -> C
    where
        T::Err: Debug,
    {
        (0..len).map(|_| self.read()).collect()
    }
}

#[macro_export]
macro_rules! putln {
    ($io:expr $(, $($args:tt)*)?) => {
        writeln!($io.writer $(, $($args)*)?).expect("failed to write output")
    };
}

#[macro_export]
macro_rules! put {
    ($io:expr, $($args:tt)*) => {
        write!($io.writer, $($args)*).expect("failed to write output")
    };
}
