#include <bits/stdc++.h>

using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n,m; cin>>n>>m;
    vector arr(n,0ll);
    for(auto& e : arr) cin>>e;
    sort(begin(arr),end(arr));

    auto prefixM = arr;
    for (int i = m; i < n; ++i)
        prefixM[i] += prefixM[i-m];

    auto cost = 0ll;
    for (int k = 0; k < n; ++k) {
        cost += prefixM[k];
        cout << cost << ' ';
    }
    cout << endl;

    return 0;
}
