
#include <bits/stdc++.h>

#define rep(a, b)   for(int a = 0; a < (b); ++a)
#define all(a)      begin(a),end(a)
#define endl        '\n'

using namespace std;
using Graph = vector<vector<int>>;
using ll = long long;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.precision(10);

    // input
    int n,f,q; cin>>n>>f>>q;
    vector req(f,0ll);
    rep(i,f) cin>>req[i];

    // apply water
    vector water(n,0ll); // initial diff array
    rep(i,q) {
        ll l,r,x; cin>>l>>r>>x; l--; // make 0-based right exclusive
        water[l]+=x;
        if(r<n) water[r]-=x;
    }
    inclusive_scan(all(water), begin(water)); // prefix sum

    // sort positions and flowers
    vector pos(n, pair(0ll,0)); // (water, pos)
    vector flowers(f, pair(0ll,0)); // (req, id)
    rep(i,n) pos[i] = {water[i],i};
    rep(i,f) flowers[i] = {req[i],i};
    sort(all(pos), greater<>());
    sort(all(flowers));

    // assign flowers
    vector sol(n,0);
    ll needed = 0;
    for(auto [water, i] : pos) {
        if(empty(flowers)) break;
        auto [req,idx] = flowers.back();
        if(water>req) continue; // not usable; wait for pos with less water
        flowers.pop_back();
        needed += req - water;
        sol[i] = idx+1;
    }

    // output
    if(!empty(flowers)) {
        cout << -1 << endl;
    } else {
        cout << needed << endl;
        rep(i,n) cout << sol[i] << ' ';
        cout << endl;
    }

    return 0;
}
