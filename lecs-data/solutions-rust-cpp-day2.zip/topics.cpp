
#include <bits/stdc++.h>

#define rep(a, b)   for(int a = 0; a < (b); ++a)
#define all(a)      begin(a),end(a)
#define endl        '\n'

using namespace std;
using Graph = vector<vector<int>>;
using ll = long long;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.precision(10);

    // input
    int n,m; cin>>n>>m;
    Graph adj(n);
    vector indeg(n,0);
    rep(i,m) {
        int u,v; cin>>u>>v; --u; --v;
        indeg[v]++;
        adj[u].push_back(v);
    }

    // topo sort
    vector<int> res;
    vector<int> todo;
    rep(i,n) if(!indeg[i]) todo.push_back(i);
    while(!empty(todo)) {
        int v = todo.back(); todo.pop_back();
        res.push_back(v);
        for(int u : adj[v]) {
            indeg[u]--;
            if(!indeg[u]) todo.push_back(u);
        }
    }

    rep(i,n) cout<<res[i]+1 << ' ';
    cout << endl;

    return 0;
}
