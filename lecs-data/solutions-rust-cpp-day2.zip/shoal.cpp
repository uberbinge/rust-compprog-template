
#include <bits/stdc++.h> // includes all; gcc only

#define rep(a, b)   for(int a = 0; a < (b); ++a)
#define all(a)      begin(a),end(a)
#define endl        '\n'

using namespace std;
using Graph = vector<vector<int>>;
using ll = long long;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.precision(10);

    // input
    int n,m; cin>>n>>m;
    Graph adj(n);
    rep(i,m) {
        int u,v; cin>>u>>v;
        adj[u].push_back(v);
        adj[v].push_back(u);
    }

    // BFS
    queue<int> q{{0}};
    vector seen(n,0);
    seen[0] = true;
    while(!empty(q)) {
        int v = q.front(); q.pop();
        for(int u : adj[v]) {
            if(seen[u]) continue;
            q.push(u);
            seen[u] = 1;
        }
    }

    bool connected = accumulate(all(seen),0) == n;
    cout << (connected ? "YES" : "NO") << endl;

    return 0;
}
