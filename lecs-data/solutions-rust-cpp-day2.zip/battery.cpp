
#include <bits/stdc++.h>

#define rep(a, b)   for(int a = 0; a < (b); ++a)
#define all(a)      begin(a),end(a)
#define endl        '\n'

using namespace std;
using Graph = vector<vector<pair<int,int>>>;
using ll = long long;

void solve() {
    // input
    int n,m; cin>>n>>m;
    Graph adj(n);
    rep(i,m) {
        int u,v,w; cin>>u>>v>>w;
        adj[u].emplace_back(v,w);
        adj[v].emplace_back(u,w);
    }

    auto check = [&](int cap) {
        queue<int> q{{0}};
        vector seen(n,0);
        seen[0] = 1;
        while(!empty(q)) {
            int v = q.front(); q.pop();
            for(auto [u,w] : adj[v]) {
                if(seen[u]) continue;
                if(w>cap) continue;
                q.push(u);
                seen[u] = 1;
            }
        }

        int reached = accumulate(all(seen),0) - 1;
        return reached * 4 >= (n-1) * 3; // check avoids floats
    };

    // binary search
    int l=0, r=1e9;
    while(r-l>1) {
        int mid = (r+l)/2;
        if(check(mid)) r=mid;
        else l=mid;
    }

    cout << r << endl;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.precision(10);

    int t; cin>>t;
    while(t--) solve();

    return 0;
}
