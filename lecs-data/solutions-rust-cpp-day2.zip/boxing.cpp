#include <bits/stdc++.h>

#define rep(a, b)   for(int a = 0; a < (b); ++a)
#define all(a)      begin(a),end(a)
#define endl        '\n'

using namespace std;
using Graph = vector<vector<int>>;
using ll = long long;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.precision(10);

    // input
    int w,h; cin>>w>>h;
    vector<string> mat(h);
    rep(i,h) cin>>mat[i];
    reverse(all(mat)); // make cell (1,1) be top left instead of bottom left

    // find enemy king
    pair<int,int> start;
    rep(i,h) rep(j,w)
        if(mat[i][j]=='k')
            start=pair(i,j);

    auto moves = array{
        pair(1,2),
        pair(2,1),
        pair(-1,2),
        pair(-2,1),
        pair(1,-2),
        pair(2,-1),
        pair(-1,-2),
        pair(-2,-1),
    };
    set blocked{'K','Q','R','B','P'};

    queue<pair<int,int>> q{{start}};
    const auto UNDISCOVERED = pair(-1,-1);
    vector prev(h, vector(w, UNDISCOVERED));
    while(!empty(q)) {
        auto [x,y] = q.front(); q.pop();
        for(auto [dx, dy] : moves) {
            int x2 = x+dx;
            int y2 = y+dy;
            if(x2<0 || x2 >= h) continue; // out of bounds
            if(y2<0 || y2 >= w) continue; // out of bounds
            if(blocked.count(mat[x2][y2])) continue; // cannot catch
            if(prev[x2][y2] != UNDISCOVERED) continue; // already visited
            q.emplace(x2,y2);
            prev[x2][y2] = pair(x,y);

            // we found the closest knight
            if(mat[x2][y2]=='N') {
                // trace back my moves
                vector<pair<int,int>> sol;
                auto cur = pair(x2,y2);
                while(cur!=start) {
                    sol.emplace_back(cur);
                    cur = prev[cur.first][cur.second];
                }
                sol.push_back(start);
                cout << "Checkmate in " << size(sol)-1 << endl;
                rep(i,size(sol)-1) {
                    auto [x,y] = sol[i];
                    auto [x2,y2] = sol[i+1];
                    cout << x+1 << ' ' << y+1 << ' ' << x2+1 << ' ' << y2+1 << endl;
                }
                return 0; // exit our program
            }
        }
    }

    cout << "Resign" << endl;

    return 0;
}
