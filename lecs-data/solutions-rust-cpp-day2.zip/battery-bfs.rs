use std::{
    collections::VecDeque,
    fmt::Debug,
    io::{self, BufWriter, Lines, StdinLock, StdoutLock, Write},
    str::FromStr,
};

fn main() {
    let mut io = Io::new();

    let t: usize = io.read();
    for _ in 0..t {
        let n: usize = io.read();
        let m: usize = io.read();
        let mut adj = vec![vec![]; n];
        let mut max_w = 0;
        for _ in 0..m {
            let a: usize = io.read();
            let b: usize = io.read();
            let w: u32 = io.read();
            adj[a].push((b, w));
            adj[b].push((a, w));
            max_w = max_w.max(w);
        }

        let required = 1 + ((n - 1) * 3).div_ceil(4);
        let mut low = 0;
        let mut high = max_w;
        while high - low > 1 {
            let mid = (low + high) / 2;
            let mut queue = VecDeque::from_iter([0]);
            let mut visited = vec![false; n];
            visited[0] = true;
            while let Some(v) = queue.pop_front() {
                for &(v2, w) in &adj[v] {
                    if w <= mid && !visited[v2] {
                        visited[v2] = true;
                        queue.push_back(v2);
                    }
                }
            }

            if visited.iter().filter(|&&vis| vis).count() >= required {
                high = mid;
            } else {
                low = mid;
            }
        }

        putln!(io, "{high}");
    }
}

struct Io {
    line: String,
    offset: usize,
    lines: Lines<StdinLock<'static>>,
    writer: BufWriter<StdoutLock<'static>>,
}

#[allow(dead_code)]
impl Io {
    fn new() -> Self {
        Self {
            line: String::new(),
            offset: 0,
            lines: io::stdin().lines(),
            writer: BufWriter::new(io::stdout().lock()),
        }
    }

    fn next_token(&mut self) -> &str {
        loop {
            if let Some(trim_len) = self.line[self.offset..].find(|c: char| !c.is_whitespace()) {
                let trimmed = &self.line[self.offset + trim_len..];
                let len = trimmed.find(char::is_whitespace).unwrap_or(trimmed.len());
                self.offset += trim_len + len;
                break &trimmed[..len];
            }

            self.line = self
                .lines
                .next()
                .expect("unexpected end-of-file")
                .expect("failed to read input");
            self.offset = 0;
        }
    }

    fn read<T: FromStr>(&mut self) -> T
    where
        T::Err: Debug,
    {
        self.next_token().parse().expect("failed to parse input")
    }

    fn collect<T: FromStr, C: FromIterator<T>>(&mut self, len: usize) -> C
    where
        T::Err: Debug,
    {
        (0..len).map(|_| self.read()).collect()
    }
}

#[macro_export]
macro_rules! putln {
    ($io:expr $(, $($args:tt)*)?) => {
        writeln!($io.writer $(, $($args)*)?).expect("failed to write output")
    };
}

#[macro_export]
macro_rules! put {
    ($io:expr, $($args:tt)*) => {
        write!($io.writer, $($args)*).expect("failed to write output")
    };
}
