use std::{
    collections::VecDeque,
    fmt::Debug,
    io::{self, BufWriter, Lines, StdinLock, StdoutLock, Write},
    str::FromStr,
};

fn main() {
    let mut io = Io::new();

    let w: usize = io.read();
    let h: usize = io.read();
    let grid: Vec<_> = (0..h).map(|_| io.read::<String>().into_bytes()).collect();

    let mut queue: VecDeque<_> = grid
        .iter()
        .enumerate()
        .flat_map(|(y, row)| row.iter().enumerate().map(move |(x, &cell)| (x, y, cell)))
        .filter(|&(_, _, cell)| cell == b'N')
        .map(|(x, y, _)| (x, y))
        .collect();
    let mut prev = vec![vec![None; w]; h];
    for &(x, y) in &queue {
        prev[y][x] = Some((x, y));
    }

    while let Some((mut x, mut y)) = queue.pop_front() {
        if grid[y][x] == b'k' {
            let mut path = vec![(x, y)];
            while grid[y][x] != b'N' {
                (x, y) = prev[y][x].unwrap();
                path.push((x, y));
            }

            putln!(io, "Checkmate in {}", path.len() - 1);
            for i in (0..path.len() - 1).rev() {
                let (x1, y1) = path[i + 1];
                let (x2, y2) = path[i];
                putln!(io, "{} {} {} {}", (h - y1), x1 + 1, (h - y2), x2 + 1);
            }
            return;
        }

        let jumps = [
            (2, 1),
            (1, 2),
            (2, -1),
            (1, -2),
            (-2, 1),
            (-1, 2),
            (-2, -1),
            (-1, -2),
        ];
        for (dx, dy) in jumps {
            let x2 = x.checked_add_signed(dx).filter(|&x2| x2 < w);
            let y2 = y.checked_add_signed(dy).filter(|&y2| y2 < h);
            if let Some((x2, y2)) = x2.zip(y2) {
                if prev[y2][x2].is_none()
                    && (!grid[y2][x2].is_ascii_uppercase() || grid[y2][x2] == b'N')
                {
                    prev[y2][x2] = Some((x, y));
                    queue.push_back((x2, y2));
                }
            }
        }
    }

    putln!(io, "Resign");
}

struct Io {
    line: String,
    offset: usize,
    lines: Lines<StdinLock<'static>>,
    writer: BufWriter<StdoutLock<'static>>,
}

#[allow(dead_code)]
impl Io {
    fn new() -> Self {
        Self {
            line: String::new(),
            offset: 0,
            lines: io::stdin().lines(),
            writer: BufWriter::new(io::stdout().lock()),
        }
    }

    fn next_token(&mut self) -> &str {
        loop {
            if let Some(trim_len) = self.line[self.offset..].find(|c: char| !c.is_whitespace()) {
                let trimmed = &self.line[self.offset + trim_len..];
                let len = trimmed.find(char::is_whitespace).unwrap_or(trimmed.len());
                self.offset += trim_len + len;
                break &trimmed[..len];
            }

            self.line = self
                .lines
                .next()
                .expect("unexpected end-of-file")
                .expect("failed to read input");
            self.offset = 0;
        }
    }

    fn read<T: FromStr>(&mut self) -> T
    where
        T::Err: Debug,
    {
        self.next_token().parse().expect("failed to parse input")
    }

    fn collect<T: FromStr, C: FromIterator<T>>(&mut self, len: usize) -> C
    where
        T::Err: Debug,
    {
        (0..len).map(|_| self.read()).collect()
    }
}

#[macro_export]
macro_rules! putln {
    ($io:expr $(, $($args:tt)*)?) => {
        writeln!($io.writer $(, $($args)*)?).expect("failed to write output")
    };
}

#[macro_export]
macro_rules! put {
    ($io:expr, $($args:tt)*) => {
        write!($io.writer, $($args)*).expect("failed to write output")
    };
}
