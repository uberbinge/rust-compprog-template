
#include <bits/stdc++.h>

#define rep(a, b)   for(int a = 0; a < (b); ++a)
#define all(a)      begin(a),end(a)
#define endl        '\n'

using namespace std;
using Graph = vector<vector<int>>;
using ll = long long;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.precision(10);

    // input
    int n,m; cin>>n>>m;
    vector w(n,0);
    rep(i,n) cin>>w[i];
    Graph adj(n);
    rep(i,m) {
        int u,v; cin>>u>>v; --u; --v;
        adj[u].push_back(v);
        adj[v].push_back(u);
    }

    // BFS
    queue<int> q{{0}};
    vector color(n,0); // 0 undiscovered, 1,2 color groups
    color[0] = 1;
    while(!empty(q)) {
        int v = q.front(); q.pop();
        for(int u : adj[v]) {
            if(color[u]) continue;
            q.push(u);
            color[u] = (color[v]==1 ? 2 : 1);
        }
    }

    ll sum1 = 0;
    ll sum2 = 0;
    rep(v,n) {
        if(color[v]==1) sum1+=w[v];
        else sum2+=w[v];
    }

    if(sum1==sum2) {
        cout << 0 << endl;
        return 0;
    }

    int winner = (sum1>sum2 ? 1 : 2);
    cout << abs(sum1-sum2) << endl;
    rep(v,n) if(color[v]==winner) cout << v+1 << ' ';
    cout << endl;

    return 0;
}
