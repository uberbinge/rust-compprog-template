#include <bits/stdc++.h>

#define rep(a, b)   for(int a = 0; a < (b); ++a)
#define all(a)      begin(a),end(a)
#define endl        '\n'

using namespace std;
using Graph = vector<vector<int>>;
using ll = long long;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.precision(10);

    // input
    int n,m; cin>>n>>m;
    vector d(n,0);
    rep(i,n) cin>>d[i];
    Graph adj(n);
    vector indeg(n,0);
    rep(i,m) {
        int u,v; cin>>u>>v; --u; --v;
        indeg[v]++;
        adj[u].push_back(v);
    }

    // topo sort
    // could use priority_queue here but I already did that for problem `order`
    // and wanted to show you how it looks with a set instead
    vector<int> res;
    set<pair<int,int>> todo;
    rep(v,n) if(!indeg[v]) todo.emplace(d[v],v);
    while(!empty(todo)) {
        auto [dv,v] = *begin(todo);
        todo.erase(begin(todo));
        res.push_back(v);
        for(int u : adj[v])
            if(!--indeg[u])
                todo.emplace(d[u],u);
    }

    rep(i,n) cout<<res[i]+1 << ' ';
    cout << endl;

    return 0;
}
