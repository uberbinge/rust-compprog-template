#include <bits/stdc++.h>

#define rep(a, b)   for(int a = 0; a < (b); ++a)
#define all(a)      begin(a),end(a)
#define endl        '\n'

using namespace std;
using Graph = vector<vector<int>>;
using ll = long long;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.precision(10);

    int n,k,a; cin>>n>>k>>a;
    vector b(n,0), p(k,0);
    rep(i,n) cin>>b[i];
    rep(i,k) cin>>p[i];

    sort(all(b));
    sort(all(p));

    int l=0, r=min(n,k)+1;
    while(r-l>1) {
        int m = (l+r)/2;
        ll work = 0;
        rep(i,m) work += max(0, p[i] - b[n-m+i]);
        if(work > a) r = m;
        else l=m;
    }

    auto help = accumulate(begin(p), begin(p)+l, 0ll) - a;
    cout << l << ' ' << max(0ll,help) << endl;

    return 0;
}
