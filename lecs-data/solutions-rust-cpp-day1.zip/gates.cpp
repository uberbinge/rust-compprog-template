#include <bits/stdc++.h>

#define rep(a, b)   for(int a = 0; a < (b); ++a)
#define all(a)      begin(a),end(a)
#define endl        '\n'

using namespace std;
using Graph = vector<vector<int>>;
using ll = long long;

void solve() {
    int n; cin>>n;
    vector<pair<ll,int>> events; // (time, diff)
    rep(i,n) {
        ll l,r; cin>>l>>r;
        events.emplace_back(l,+1);
        events.emplace_back(r,-1);
    }
    sort(all(events));

    int cur=0, res=0;
    for(auto [t,d] : events) {
        cur+=d;
        res = max(res,cur);
    }
    cout << res << endl;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.precision(10);

    int t; cin>>t;
    while(t--) solve();

    return 0;
}
