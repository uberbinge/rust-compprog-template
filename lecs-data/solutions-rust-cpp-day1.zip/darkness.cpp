#include <bits/stdc++.h>

#define rep(a, b)   for(int a = 0; a < (b); ++a)
#define all(a)      begin(a),end(a)
#define endl        '\n'

using namespace std;
using Graph = vector<vector<int>>;
using ll = long long;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.precision(10);

    int n,k; cin>>n>>k; n++;
    vector arr(n,pair(0,0));
    rep(i,n) cin>>arr[i].first;
    rep(i,n) cin>>arr[i].second;

    double l = 0, r = 1e9;
    while(r-l>1e-6) {
        auto m = (l+r)/2;

        vector<tuple<double, int, bool>> events;  // (pos, idx, is_start)
        rep(i,n) {
            auto [p,v] = arr[i];
            events.emplace_back(p - m*v, i, true);
            events.emplace_back(p + m*v, i, false);
        }
        sort(all(events));

        vector done(n, 0); // number of placed portals at start of interval
        int portals = 0;
        for(auto [pos, i, is_start] : events) {
            if(is_start) done[i] = portals;
            if(!is_start && done[i]==portals) portals++;
        }
        if(portals<=k+1) r=m;
        else l=m;
    }

    cout << l << endl;
    return 0;
}
