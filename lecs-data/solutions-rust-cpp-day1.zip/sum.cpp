#include <bits/stdc++.h>

#define rep(a, b)   for(int a = 0; a < (b); ++a)
#define all(a)      begin(a),end(a)
#define endl        '\n'

using namespace std;
using Graph = vector<vector<int>>;
using ll = long long;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.precision(10);

    int n; cin>>n;
    vector arr(n,0);
    rep(i,n) cin>>arr[i];
    cout << accumulate(all(arr), 0ll) << endl;

    return 0;
}
