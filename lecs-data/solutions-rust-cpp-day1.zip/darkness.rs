use std::{
    collections::HashSet,
    fmt::Debug,
    io::{self, BufWriter, Lines, StdinLock, StdoutLock, Write},
    str::FromStr,
};

#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord)]
enum EventType {
    End,
    Start,
}

fn main() {
    let mut io = Io::new();

    let n = io.read::<usize>() + 1;
    let k: usize = io.read();
    let x: Vec<f64> = io.collect(n);
    let v: Vec<f64> = io.collect(n);

    let mut low = 0.0;
    let mut high = 1e7;
    while high - low > 1e-5 {
        let mid = (low + high) / 2.0;

        let mut events: Vec<_> = x
            .iter()
            .zip(&v)
            .enumerate()
            .flat_map(|(i, (&xi, &vi))| {
                [
                    (xi - mid * vi, EventType::Start, i),
                    (xi + mid * vi, EventType::End, i),
                ]
            })
            .collect();
        events
            .sort_unstable_by(|&(x1, ty1, _), &(x2, ty2, _)| x1.total_cmp(&x2).then(ty1.cmp(&ty2)));
        let mut count = 0;
        let mut active = HashSet::new();
        for (_, ty, i) in events {
            match ty {
                EventType::End if active.contains(&i) => {
                    count += 1;
                    active.clear();
                }
                EventType::End => {}
                EventType::Start => {
                    active.insert(i);
                }
            }
        }

        if count <= k + 1 {
            high = mid;
        } else {
            low = mid;
        }
    }

    putln!(io, "{high:.9}");
}

struct Io {
    line: String,
    offset: usize,
    lines: Lines<StdinLock<'static>>,
    writer: BufWriter<StdoutLock<'static>>,
}

impl Io {
    fn new() -> Self {
        Self {
            line: String::new(),
            offset: 0,
            lines: io::stdin().lines(),
            writer: BufWriter::new(io::stdout().lock()),
        }
    }

    fn next_token(&mut self) -> &str {
        loop {
            if let Some(trim_len) = self.line[self.offset..].find(|c: char| !c.is_whitespace()) {
                let trimmed = &self.line[self.offset + trim_len..];
                let len = trimmed.find(char::is_whitespace).unwrap_or(trimmed.len());
                self.offset += trim_len + len;
                break &trimmed[..len];
            }

            self.line = self
                .lines
                .next()
                .expect("unexpected end-of-file")
                .expect("failed to read input");
            self.offset = 0;
        }
    }

    fn read<T: FromStr>(&mut self) -> T
    where
        T::Err: Debug,
    {
        self.next_token().parse().expect("failed to parse input")
    }

    fn collect<T: FromStr, C: FromIterator<T>>(&mut self, len: usize) -> C
    where
        T::Err: Debug,
    {
        (0..len).map(|_| self.read()).collect()
    }
}

#[macro_export]
macro_rules! putln {
    ($io:expr, $($args:tt)*) => {
        writeln!($io.writer, $($args)*).expect("failed to write output")
    };
}

#[macro_export]
macro_rules! put {
    ($io:expr, $($args:tt)*) => {
        write!($io.writer, $($args)*).expect("failed to write output")
    };
}
