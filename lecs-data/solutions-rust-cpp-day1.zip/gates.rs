use std::{
    fmt::Debug,
    io::{self, BufWriter, Lines, StdinLock, StdoutLock, Write},
    str::FromStr,
};

#[derive(PartialEq, Eq, PartialOrd, Ord)]
enum EventType {
    End,
    Start,
}

fn main() {
    let mut io = Io::new();

    let t: usize = io.read();
    for _ in 0..t {
        let n: usize = io.read();
        let mut events: Vec<_> = (0..n)
            .flat_map(|_| {
                let l: u64 = io.read();
                let r: u64 = io.read();
                [(l, EventType::Start), (r, EventType::End)]
            })
            .collect();
        events.sort_unstable();

        let mut cur = 0;
        let ans = events
            .into_iter()
            .map(|(_, ty)| {
                cur = match ty {
                    EventType::Start => cur + 1,
                    EventType::End => cur - 1,
                };
                cur
            })
            .max()
            .unwrap_or_default();
        putln!(io, "{ans}");
    }
}

struct Io {
    line: String,
    offset: usize,
    lines: Lines<StdinLock<'static>>,
    writer: BufWriter<StdoutLock<'static>>,
}

impl Io {
    fn new() -> Self {
        Self {
            line: String::new(),
            offset: 0,
            lines: io::stdin().lines(),
            writer: BufWriter::new(io::stdout().lock()),
        }
    }

    fn next_token(&mut self) -> &str {
        loop {
            if let Some(trim_len) = self.line[self.offset..].find(|c: char| !c.is_whitespace()) {
                let trimmed = &self.line[self.offset + trim_len..];
                let len = trimmed.find(char::is_whitespace).unwrap_or(trimmed.len());
                self.offset += trim_len + len;
                break &trimmed[..len];
            }

            self.line = self
                .lines
                .next()
                .expect("unexpected end-of-file")
                .expect("failed to read input");
            self.offset = 0;
        }
    }

    fn read<T: FromStr>(&mut self) -> T
    where
        T::Err: Debug,
    {
        self.next_token().parse().expect("failed to parse input")
    }

    fn collect<T: FromStr, C: FromIterator<T>>(&mut self, len: usize) -> C
    where
        T::Err: Debug,
    {
        (0..len).map(|_| self.read()).collect()
    }
}

#[macro_export]
macro_rules! putln {
    ($io:expr, $($args:tt)*) => {
        writeln!($io.writer, $($args)*).expect("failed to write output")
    };
}

#[macro_export]
macro_rules! put {
    ($io:expr, $($args:tt)*) => {
        write!($io.writer, $($args)*).expect("failed to write output")
    };
}
