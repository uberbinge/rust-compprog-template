#include <bits/stdc++.h>

#define rep(a, b)   for(int a = 0; a < (b); ++a)
#define all(a)      begin(a),end(a)
#define endl        '\n'

using namespace std;
using Graph = vector<vector<int>>;
using ll = long long;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.precision(10);

    int n; cin>>n;
    vector prob(n, array{0,0,0}); // (l,r,id)
    for(auto& [l,r,_] : prob) cin>>l>>r;
    rep(i,n) prob[i][2] = i;
    sort(all(prob));

    priority_queue<pair<int,int>> active; // (-r,id)
    int next = 0;
    rep(i,n) {
        for (; next<n && prob[next][0]==i+1; ++next)
            active.emplace(-prob[next][1], prob[next][2]);
        auto [r,id] = active.top(); active.pop();
        cout << id+1 << ' ';
    }

    return 0;
}

