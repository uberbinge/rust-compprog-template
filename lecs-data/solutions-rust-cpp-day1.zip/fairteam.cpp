#include <bits/stdc++.h>

#define rep(a, b)   for(int a = 0; a < (b); ++a)
#define all(a)      begin(a),end(a)
#define endl        '\n'

using namespace std;
using Graph = vector<vector<int>>;
using ll = long long;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.precision(10);

    int n; cin >> n;
    vector arr(n,0);
    rep(i,n) cin >> arr[i];
    int best = 1e9;
    int total = accumulate(all(arr),0);
    int xsum = 0;
    for (int i=0; i<n-2; ++i) {
        xsum += arr[i];
        int ysum = 0;
        for (int j=i+1; j<n-1; ++j) {
            ysum += arr[j];
            int zsum = total-xsum-ysum;
            best = min(best, max(xsum,max(ysum,zsum)) - min(xsum,min(ysum,zsum)));
        }
    }
    cout << best << endl;

    return 0;
}

